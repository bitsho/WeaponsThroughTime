# Histography Timeline Skill

**Name:** `histography-timeline`  
**Version:** `1.0.0`  
**Created:** `2026-09-16`  
**Status:** Production personal Skill package

This package formalizes the reusable Histography product rules developed across APUSH and AP World History projects and generalizes them for AP European History, Chinese history, and other history courses.

## Trigger examples

- “用 Histography Skill 做一个 AP European History 时间轴。”
- “继续修改 APWH Histography。”
- “做一个中国通史互动时间轴，沿用之前 Histography 的玩法。”
- “修复 Cinema Mode 的字幕和图片加载问题。”
- “把事件池从 300 扩展到 500 并重新做重要度。”

## Governing stack

1. Current explicit user request
2. Project-specific PRD / current baseline
3. `histography-timeline`
4. `html-ui-design-governance`
5. Current course framework / source authority

## Package contents

- `SKILL.md` — controlling workflow and product contract
- `references/course-adapters.md` — how to adapt the shell to different history courses
- `references/event-model-and-relations.md` — event and relation data rules
- `references/cinema-mode.md` — Cinema Mode contract
- `references/qa-checklist.md` — release checklist
- `templates/event.schema.json` — canonical event schema example
- `templates/project-config.example.json` — project adapter example
- `SOURCES.md` — provenance of the rules

