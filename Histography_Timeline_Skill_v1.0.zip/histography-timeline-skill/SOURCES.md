# Sources and Provenance

This Skill consolidates the user's established Histography product rules and patterns from prior APUSH and AP World History implementations, including:

- APUSH Histography legacy builds with Concise/Classic modes, importance 1-5, event-type filtering, Wikipedia linking, hover/detail behavior, and Cinema Mode.
- AP World History bilingual builds with theme/region dimension switching, primary/secondary region treatment, three palette options, and bilingual Cinema controls.
- User-confirmed cross-project rules: Information First, bilingual Cinema Mode, adjustable playback speed, importance-based density, course/framework weighting, and reusable adaptation to AP European History and Chinese history.
- `/Skills/HTML_UI_Design_Skill_Stack/SKILL.md` as the governing shared HTML/UI QA and design process.

The Skill intentionally separates reusable product grammar from course-specific taxonomies. Current course frameworks and user-provided source materials remain authoritative for course content.
