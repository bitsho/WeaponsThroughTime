---
name: histography-timeline
version: 1.0.0
status: production
created: 2026-09-16
description: >
  Create, adapt, extend, redesign, debug, and quality-assure Histography-style interactive
  history timelines for APUSH, AP World History, AP European History, Chinese history,
  and other history courses. Governs event selection and weighting, 1-5 importance,
  Concise/Classic/Cinema modes, bilingual UI, course/theme/region dimensions,
  historical relations, sources and imagery, responsive behavior, and single-HTML delivery.
  Trigger on Histography, history timeline, interactive historical timeline, APUSH timeline,
  APWH timeline, AP European timeline, 中国历史时间轴, 影院模式, Cinema Mode, or requests
  to reuse/extend the user's Histography framework.
---

# Histography Timeline Skill

## 0. Mission

Build an interactive historical map of time that lets a learner answer three questions quickly:

1. What happened, and when?
2. What mattered most at the current level of zoom/detail?
3. How does this event connect to categories, regions, themes, causes, consequences, and other events?

The timeline is a learning interface, not a decorative poster. Temporal structure, historical significance,
comparability, and navigability own the design.

## 1. Governing hierarchy

When requirements conflict, apply this order:

1. The user's current explicit request.
2. Project-specific PRD, handoff, current baseline, and latest confirmed rules.
3. This Histography Skill.
4. `/Skills/HTML_UI_Design_Skill_Stack/SKILL.md` for shared HTML/UI design, accessibility, regression, and release-gate rules.
5. Current authoritative course framework or user-provided syllabus/source set.
6. General frontend conventions.

For an existing Histography project, preserve unaffected product truth. Never silently rebuild from an older version.

## 2. First principles

### 2.1 Time is the primary spatial axis

Chronology must remain visually legible under zoom, filtering, language changes, and mode changes. Do not let visual style obscure temporal order.

### 2.2 Information First

Hierarchy precedes decoration. The learner should understand the current time window, active filters, display mode, importance threshold, and selected event before noticing ornamental styling.

### 2.3 Semantic zoom

Zooming or detail changes must reveal meaningful historical granularity. Use importance and event density to decide which events and labels appear; do not merely scale all marks uniformly.

### 2.4 Stable visual semantics

A visual variable has one meaning within a project:

- X position = time.
- Dot/node size = historical importance.
- Color = one declared dimension such as event type or course theme.
- Lane/row = one declared grouping dimension such as category, theme, or region.
- Opacity/dash = secondary status only when the project uses primary/secondary regions.

Do not reuse the same visual channel for unrelated meanings.

### 2.5 Historical significance is explicit

Every event receives an importance value from 1 to 5. Importance is comparative within the course/project and should be justified by curricular centrality, long-term impact, explanatory power, and historical consensus.

### 2.6 Overview and detail must coexist

The interface must support rapid macro scanning and deep event exploration without forcing a page change.

### 2.7 Evidence over ornament

Historical images, maps, dates, concise explanations, relationships, and sources outrank decorative graphics.

## 3. Task routing

Classify the task internally before editing.

### Mode N — New Histography build

Use for a new course, period, country, or subject.

1. Define audience, course/framework, time extent, target event count, language mode, delivery format, and source authority.
2. Build period/unit weighting before selecting individual events.
3. Define category/theme taxonomy and optional region taxonomy.
4. Build event pool and assign importance 1-5.
5. Validate chronology, coverage, balance, duplicates, and category/region mappings.
6. Implement Concise and Classic modes.
7. Implement Cinema Mode when requested or when the project inherits the full Histography product.
8. Apply the HTML/UI Governance Skill for visual system and shared interaction quality.
9. Run historical-data, functional, visual, responsive, accessibility, and regression QA.
10. Deliver the final runnable artifact, normally a single HTML when feasible.

### Mode I — Existing Histography iteration

1. Read the latest HTML baseline and any PRD/handoff before editing.
2. Identify consequential ambiguity only; otherwise proceed with the safest interpretation.
3. Build a preserve list covering data, modes, themes, language behavior, filters, sources, Cinema Mode, and current working interactions.
4. Map upstream/downstream impact before changing shared data structures or rendering logic.
5. Make the smallest coherent change set.
6. Regression-test the changed state and adjacent states.
7. Deliver the next version, never an earlier baseline.

### Mode E — Event-pool expansion or course migration

1. Preserve the product shell unless redesign is requested.
2. Recompute period/unit weights for the target course.
3. Re-evaluate all events, not only new events, when the event count or course scope changes materially.
4. Rebalance importance distribution and category/region coverage.
5. Re-run label-density and Classic-lane layout QA.
6. Rebuild Cinema ordering and relation graph from the updated data.

### Mode B — Bug fix

1. Reproduce the defect or identify the failing state from the supplied file/screenshot.
2. Locate root cause before applying style patches.
3. Inspect blast radius across Concise/Classic, language, palette, filters, importance, Cinema, relation graph, responsive breakpoints, and saved state.
4. Fix the owning layer.
5. Test reported case + adjacent cases + one previously working end-to-end path.

### Mode R — Visual redesign

1. Preserve historical data, product logic, mode semantics, and course framework.
2. Use the HTML/UI Governance Skill's design stack for direction, tokens, audit, and compliance.
3. Keep Histography's stable semantic mappings unless the user explicitly requests a data-visualization redesign.
4. Compare before/after at identical time window, filters, language, and event selection.

## 4. Course adapter contract

Every Histography project must define an adapter with:

- `course_id`
- `course_name_en`
- `course_name_zh`
- `time_start`
- `time_end`
- `framework_source`
- `periods_or_units`
- `period_weights`
- `target_event_count`
- `category_dimension`
- `categories`
- optional `theme_dimension`
- optional `themes`
- optional `region_dimension`
- optional `regions`
- `default_dimension`
- `source_policy`
- `language_policy`

Rules:

- AP courses: use the current College Board framework or user-supplied official framework as the curricular authority.
- Non-AP courses: use the user's syllabus or a clearly stated historical periodization.
- Do not copy one course's taxonomy into another course merely because the UI is shared.
- Event counts are project targets, not universal constants. When the user specifies a count, honor it; otherwise derive one from scope and density.

See `references/course-adapters.md`.

## 5. Event selection and weighting

### 5.1 Build from periods/units first

Allocate the event budget by course period/unit importance before filling individual events. Avoid collecting famous events first and trying to balance later.

### 5.2 Event eligibility

An event belongs in the pool when it materially contributes to one or more of:

- course/framework coverage;
- causal explanation;
- institutional or structural change;
- major conflict/diplomacy;
- social/cultural transformation;
- economic/technological transformation;
- rights, law, or governance change;
- cross-regional interaction;
- representative turning points or high-yield comparison cases.

Avoid trivia, isolated anecdotes, and near-duplicate events unless a course objective specifically requires them.

### 5.3 Importance 1-5

Use the following semantics:

- **5 — Anchor:** indispensable macro turning point; should remain visible at overview level.
- **4 — Major:** central to a period/unit and explains multiple downstream developments.
- **3 — Core:** course-relevant event needed for coherent understanding.
- **2 — Supporting:** useful context or mechanism detail, visible at higher detail.
- **1 — Fine grain:** enrichment/detail, visible only at the most detailed level.

Importance must remain comparable across categories. Do not inflate one category to make it visually dominant.

### 5.4 Dates

Prefer the most precise defensible date:

- exact day when historically meaningful and reliable;
- otherwise month/year;
- otherwise year;
- use circa/range when precision is uncertain.

Store machine-sortable date fields separately from display labels.

## 6. Canonical event data model

Each event should support at least:

```json
{
  "id": "stable-kebab-id",
  "title_en": "Event title",
  "title_zh": "中文标题",
  "date_start": "1776-07-04",
  "date_end": null,
  "date_precision": "day",
  "date_label_en": "July 4, 1776",
  "date_label_zh": "1776年7月4日",
  "importance": 5,
  "category": "Politics & Government",
  "themes": [],
  "primary_region": null,
  "secondary_regions": [],
  "summary_en": "",
  "summary_zh": "",
  "canonical_url": "",
  "image": {
    "src": "",
    "source_url": "",
    "creator": "",
    "date": "",
    "caption_en": "",
    "caption_zh": ""
  },
  "relations": []
}
```

Requirements:

- `id` is stable across versions.
- Display-language changes must never mutate canonical event identity.
- Multi-region events are one event object with one primary region plus zero or more secondary regions; do not duplicate the underlying event record.
- Separate facts/data from presentation state.

See `templates/event.schema.json`.

## 7. Concise Mode

Purpose: maximize temporal scanning and pattern recognition.

Required behavior:

- compact marks and short labels;
- importance-driven label visibility;
- semantic zoom or equivalent detail adaptation;
- scroll/wheel zoom and drag/pan where appropriate;
- clear current time-window status;
- category/theme/region filtering;
- label toggle;
- reset view;
- no persistent overlapping labels after pan/zoom/filter changes.

When density rises, hide or stagger lower-importance labels before shrinking text below comfortable readability.

## 8. Classic Mode

Purpose: compare events across lanes/categories while preserving chronology.

Rules:

- lane position communicates grouping dimension;
- events in the same lane use consistent vertical logic;
- selected/active event remains identifiable;
- time axis remains shared across lanes;
- default maximum simultaneously displayed lanes/categories is **5** when screen density would otherwise become unreadable;
- if more groups exist, use a controlled lane scrollbar or equivalent progressive disclosure rather than compressing all lanes into illegibility;
- event and label size may reduce moderately relative to Concise mode but must remain readable;
- leftmost and rightmost events must remain fully visible within the plotting bounds.

## 9. Dimension switching: category, theme, region

A course may expose more than one grouping dimension.

### Region dimension

When an event spans regions:

- choose exactly one primary region;
- show the event in secondary regions only as a secondary representation;
- secondary representation uses materially lower opacity;
- a primary-secondary relationship uses a dashed connection when the layout calls for a visual link;
- counts and Cinema event totals deduplicate the underlying event;
- switching dimensions must preserve sensible selection memory where feasible.

AP World History projects should default to the course's official region model when the user requests the region dimension.

## 10. Bilingual and localization rules

When bilingual mode is enabled:

- all product UI must be localized, not only event titles;
- event titles, date labels, Cinema text, relation labels, controls, help text, and image captions must follow the active language;
- English Wikipedia remains the canonical source link when that is the project's source policy;
- Chinese summaries may use a Chinese source/translation layer, but must not silently change the canonical historical referent;
- Chinese titles should be concise enough to preserve timeline readability while remaining historically accurate;
- Chinese punctuation uses full-width punctuation;
- project typography rules override generic typography rules.

Language switching must not reset time window, filters, selected event, Cinema position, or palette unless explicitly designed to do so.

## 11. Sources and historical integrity

### 11.1 Source hierarchy

Use, in order where applicable:

1. User-provided official course framework/syllabus/source set.
2. Official curriculum/framework sources.
3. Authoritative archives, museums, libraries, government/institutional sources.
4. High-quality reference works.
5. Wikipedia as the canonical navigation/reference layer when the product specifies it.

### 11.2 Wikipedia policy

For legacy Histography compatibility, the English Wikipedia page may remain the canonical click-through source. Validate that each URL resolves to the intended event/person/topic and avoid ambiguous or broken links.

### 11.3 Images

Prefer historically relevant, rights-compatible images from Wikimedia Commons, archives, museums, libraries, or official collections.

Store image source metadata separately from the caption. Do not use generic stock imagery when a real historical image is available.

## 12. Historical relation graph

Relations must be curated enough to teach, not merely generated by proximity.

Supported relation semantics may include:

- Cause
- Consequence
- Response
- Escalation
- Institutional development
- Long-term impact
- Context
- Comparison/parallel development

Each edge should include:

- `source`
- `target`
- `type`
- optional `weight`
- optional bilingual label

Rules:

- direction must make historical sense;
- avoid dense all-to-all graphs;
- prioritize explanatory relations;
- center event remains visually dominant;
- graph nodes must be clickable when the interface supports navigation;
- edge labels remain readable at normal zoom;
- graph reset/zoom/pan behavior must be deterministic.

## 13. Cinema Mode

Cinema Mode is a guided historical screening built from the same event data.

### 13.1 Setup

Allow the learner to configure, as applicable:

- category/theme/region subset;
- date range;
- detail/importance threshold;
- playback speed;
- language.

Retain the established four-speed model for projects inheriting the legacy Histography experience unless the user requests another control scheme.

### 13.2 Playback

Required behaviors for the full product:

- play/pause;
- previous/next;
- first/last or equivalent navigation;
- speed change;
- keyboard shortcuts;
- exit Cinema;
- saved playback position;
- resume previous screening or start new;
- current position/total;
- event relations;
- source link;
- image and image-source metadata;
- graceful fallback when summary/image/source loading fails.

### 13.3 Content density

Default guidance for the legacy full-screen Cinema treatment:

- event narrative: approximately **150-200 words** when a full explanatory paragraph is appropriate;
- image caption/description: normally no more than **40 words**;
- concise variants may be shorter when screen size or course level requires it;
- text must fit without clipping; edit content before shrinking text excessively.

### 13.4 Preloading

For remote Cinema assets, preload ahead of the current position. Legacy Histography behavior may use an approximately **30% forward buffer**; adapt to asset size and browser constraints while preserving responsive playback.

### 13.5 Image-caption integrity

The caption shown in Chinese must translate the actual English caption/source description for that event. Do not replace it with generic templates such as “某事件相关历史图像”.

## 14. Visual system

Histography inherits the user's HTML/UI Design Governance Skill.

### Stable design requirements

- Information First.
- High-density information remains scannable.
- Motion is restrained and state-linked.
- Use centralized design tokens.
- Avoid generic AI-dashboard styling, gratuitous glassmorphism, and repetitive card grids.
- Timeline, filters, and event relationships remain visually primary.

### Default palette set for the modern reusable Histography shell

When no project-specific palette exists, the established three-theme family may be used:

- **Atlas Archive** — archival/editorial base.
- **Gilded Alloy** — metallic/luxury dark-light contrast.
- **Porcelain Nocturne** — restrained porcelain/night contrast.

A project may replace these themes, but a palette switch must preserve semantic event colors, contrast, and selected/hover/focus states.

## 15. Interaction contract

The full Histography shell should support, where applicable:

- wheel/scroll zoom;
- drag to pan;
- reset view;
- category/theme/region ALL/NONE or equivalent controls;
- importance/detail slider 1-5;
- AUTO DETAIL / MANUAL DETAIL;
- CONCISE / CLASSIC;
- label toggle;
- event hover preview;
- event click/open detail/source;
- palette switch;
- language switch;
- Cinema Mode.

Do not add controls merely because they existed in another course; add them when the adapter/product requires them.

## 16. State and persistence

When persistence is used, store user-facing state such as:

- language;
- palette;
- display mode;
- grouping dimension;
- active filters;
- detail mode/threshold;
- label visibility;
- Cinema screening and playback position.

Version saved state keys when schema changes. A stale local-storage value must not break rendering.

## 17. Responsive behavior

Minimum representative checks:

- narrow mobile;
- tablet;
- standard desktop;
- wide desktop.

Rules:

- no unintended horizontal page overflow;
- plot can pan internally when required;
- controls remain reachable;
- event labels never become permanently detached from their events;
- hover-only interactions need touch-accessible alternatives;
- Cinema copy remains readable and media does not push controls off-screen;
- relation graph may simplify on small screens if required, but the core event detail remains available.

## 18. Performance rules

- Separate event data, indices, render state, and UI state.
- Precompute category/region/theme indices for large pools.
- Throttle/debounce expensive redraws caused by pan/zoom/resize.
- Do not bind duplicate event handlers after re-render.
- For hundreds of events, prefer a rendering strategy appropriate to density (Canvas, SVG, or hybrid) rather than forcing every element into an expensive DOM tree.
- Keep remote fetches out of the critical timeline render path.
- Provide fallbacks for unavailable external summaries/images.

## 19. Mandatory modification impact checklist

Before changing an existing Histography build, inspect impact on:

- event IDs and event ordering;
- dates/date precision;
- importance 1-5;
- category/theme/region taxonomy;
- primary/secondary region mapping;
- Concise mode;
- Classic mode;
- visible-lane cap/scrolling;
- label collision and edge clipping;
- AUTO/MANUAL detail;
- language switching;
- palette switching;
- hover/detail panel;
- Wikipedia/source links;
- images/captions;
- relation graph;
- Cinema filtering/order/playback/resume;
- saved state;
- mobile/tablet/desktop layouts;
- single-HTML packaging/deployment.

## 20. Mandatory QA release gates

### A. Historical data integrity

- Event chronology is correct.
- No accidental duplicates.
- Importance values are 1-5 and distribution is plausible.
- Category/theme/region mappings are valid.
- Primary/secondary region logic is valid.
- Bilingual titles refer to the same event.
- Source URLs resolve to the intended topic.

### B. Timeline rendering

- Earliest and latest events are fully visible.
- No catastrophic label overlap at default view.
- Pan/zoom updates labels and hit areas correctly.
- Filtering does not leave ghost marks/labels.
- Importance/detail changes redraw deterministically.

### C. Classic Mode

- Lane labels and events align.
- At most the intended number of lanes are simultaneously compressed into the viewport; default cap is 5 when density requires it.
- Lane scrolling preserves the shared time axis.
- Secondary-region representations remain visibly secondary.

### D. Bilingual/localization

- All visible UI switches language consistently.
- Chinese titles remain concise and accurate.
- Cinema summaries and captions match the current event.
- Language switching preserves user state.

### E. Cinema

- Setup filters produce the correct deduplicated event sequence.
- Play/pause/previous/next/speed/exit work.
- Saved position resumes correctly.
- Remote-content failures degrade gracefully.
- Text does not clip.
- Image metadata/source belong to the current image/event.
- Relation graph navigation does not desynchronize Cinema state.

### F. Visual/theme

- All palettes maintain readable contrast.
- Semantic category/theme colors remain distinguishable.
- Selected/hover/focus states remain visible.
- No unintended grayscale/desaturation of historical images.

### G. Responsive/accessibility

- Keyboard controls work where defined.
- Focus states are visible.
- Touch targets are usable.
- `aria` state is updated for toggles/dialogs where applicable.
- Reduced-motion behavior is respected for significant animation when feasible.

### H. Regression

- Re-test the reported change/bug.
- Re-test one adjacent shared subsystem.
- Re-test one complete representative path from opening timeline → filtering/zooming → selecting event → Cinema/detail → returning to timeline.

## 21. Delivery discipline

For implementation tasks:

- deliver the actual final runnable HTML, not only diffs or instructions, unless the user asks for code snippets;
- preserve single-file HTML when that is the project contract;
- state source baseline and new version when versioning exists;
- do not claim QA passed unless it was actually inspected or executed;
- keep internal Skill rules and developer-facing declarations out of the webpage UI.

## 22. Course-specific examples without hard-coding

### APUSH legacy pattern

- timeline beginning around 1491 and extending to the project's present endpoint;
- event type/category as a major grouping/color dimension;
- importance 1-5;
- English Wikipedia canonical navigation layer;
- bilingual UI where enabled.

### AP World History: Modern legacy pattern

- timeline beginning around 1200;
- six course themes as one dimension;
- official region dimension available and commonly defaulted;
- one primary region plus optional secondary regions;
- secondary-region representation faded and visually subordinate;
- region/theme switch;
- bilingual UI.

### AP European History / Chinese history / other courses

Use the same product grammar while deriving periodization, categories, themes, and event weights from that course's own framework. Do not force APUSH/APWH semantics into unrelated histories.

## 23. Required companion references

Read as needed:

- `references/course-adapters.md`
- `references/event-model-and-relations.md`
- `references/cinema-mode.md`
- `references/qa-checklist.md`
- `templates/event.schema.json`
- `templates/project-config.example.json`

