# Cinema Mode Contract

## Goal

Turn a filtered event sequence into a guided historical screening while preserving the same canonical event data as the timeline.

## Setup controls

Where applicable:

- grouping/category filters;
- date range;
- detail/importance;
- playback speed;
- language.

## Playback controls

- play/pause;
- previous/next;
- jump first/last or equivalent;
- speed change;
- keyboard shortcuts;
- exit;
- resume saved screening;
- new screening.

## Content

For the full-screen legacy treatment:

- narrative target: approximately 150-200 words when appropriate;
- caption/description: normally <=40 words;
- actual caption translation in bilingual mode;
- image source/creator/date metadata;
- canonical source link;
- event relation graph.

## Loading

Remote data must fail gracefully. Keep the current event usable when Wikipedia/image metadata is unavailable. Preload forward from the current position; legacy projects may use about a 30% forward buffer.

## Persistence

Save enough information to resume the same screening safely after reload. Invalidate or migrate stale saved state if the event schema/version changes.

