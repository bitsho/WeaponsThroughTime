# Histography Release Checklist

## Data

- [ ] Correct chronological order
- [ ] No unintended duplicates
- [ ] Importance values are all 1-5
- [ ] Event-count target met
- [ ] Period/unit allocation matches adapter
- [ ] Category/theme/region mappings valid
- [ ] Primary/secondary region mappings valid
- [ ] Canonical links point to intended topics
- [ ] Chinese/English titles refer to the same event

## Concise Mode

- [ ] Pan works
- [ ] Zoom works
- [ ] Reset works
- [ ] Label toggle works
- [ ] Importance/detail logic works
- [ ] Filters redraw correctly
- [ ] No ghost labels
- [ ] Earliest/latest events fully visible

## Classic Mode

- [ ] Shared time axis preserved
- [ ] Lane labels align
- [ ] Default visible-lane density is readable
- [ ] More than 5 lanes use controlled scrolling/disclosure when needed
- [ ] Secondary-region copies are visibly secondary
- [ ] No edge clipping

## Bilingual

- [ ] Entire UI changes language
- [ ] Event/date labels change language
- [ ] Cinema text changes language
- [ ] Captions match active event and language
- [ ] Switching language preserves current state

## Cinema

- [ ] Filtered sequence is correct and deduplicated
- [ ] Play/pause works
- [ ] Previous/next works
- [ ] Speed works
- [ ] Keyboard controls work
- [ ] Resume works
- [ ] New screening works
- [ ] Summary fallback works
- [ ] Image fallback works
- [ ] Image metadata matches image
- [ ] Relation graph navigation stays synchronized
- [ ] No clipped text

## Themes and responsive

- [ ] All palettes preserve semantic colors and contrast
- [ ] Focus/selected/hover states visible
- [ ] Narrow mobile checked
- [ ] Tablet checked
- [ ] Desktop checked
- [ ] Wide desktop checked
- [ ] Touch alternatives exist for hover-only actions

## Regression

- [ ] Requested change retested
- [ ] Adjacent shared subsystem retested
- [ ] Full representative user path retested

