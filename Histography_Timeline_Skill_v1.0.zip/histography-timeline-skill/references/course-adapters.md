# Course Adapters

## Purpose

The Histography shell is reusable; historical taxonomy is course-specific. An adapter converts a course/framework into the shared timeline grammar.

## Required adapter decisions

1. Time extent.
2. Period/unit boundaries and weights.
3. Target event count.
4. Event-category taxonomy.
5. Theme taxonomy, if distinct from event categories.
6. Region taxonomy, if pedagogically useful.
7. Default grouping dimension.
8. Source authority.
9. Language mode.
10. Default palettes and typography, if project-specific.

## APUSH

Use the current AP U.S. History framework supplied by the user or verified from the official course framework. Preserve the established product language of importance 1-5, Concise/Classic/Cinema, event-type grouping, and canonical source behavior. Do not copy AP World History's region model into APUSH unless explicitly requested.

## AP World History: Modern

Use the current official AP World History framework. The legacy implementation uses six course themes and a region dimension. When region mode is enabled, maintain one primary region and zero or more secondary regions per event. Counts must deduplicate events displayed in several regions.

## AP European History

Use the current official AP European History periods/units and skills/themes. Rebuild event weights from that framework; do not inherit APUSH's category distribution mechanically.

## Chinese history

Define the requested scope first: ancient, imperial, modern, PRC, or full survey. Establish periodization explicitly before event selection. For survey courses, keep political, social, economic, intellectual/cultural, military/diplomatic, institutional/legal, and technological dimensions distinguishable without forcing every event into a single modern Western taxonomy.

## General history projects

When no official framework exists:

- identify learning audience and course purpose;
- define a periodization;
- allocate event budget by period significance and teaching time;
- define a small, stable taxonomy;
- document the source policy;
- validate event balance before implementation.

