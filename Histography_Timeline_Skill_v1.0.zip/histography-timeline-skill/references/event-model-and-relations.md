# Event Model and Relations

## Event identity

Event IDs are stable, language-neutral identifiers. Titles and summaries are localized fields; they never become IDs.

## Date model

Store sortable dates separately from display labels. Support exact dates, month/year, year, circa, and ranges.

## Importance

Every event is scored 1-5:

- 5: anchor
- 4: major
- 3: core
- 2: supporting
- 1: fine-grain

A change in total event count may require re-scoring the whole pool.

## Multi-dimensional classification

An event may have:

- one primary category;
- zero or more themes;
- one primary region;
- zero or more secondary regions.

The UI may project the same event into different dimensions, but the data layer keeps one canonical event object.

## Relation model

Recommended edge types:

- Cause
- Consequence
- Response
- Escalation
- Institutional development
- Long-term impact
- Context
- Comparison / parallel development

Each edge should be historically interpretable. High-weight edges should represent explanatory relationships, not mere chronological adjacency.

## Graph-density rule

Prefer a sparse explanatory graph. A learner should be able to see why neighbors matter. Avoid all-to-all connectivity and relation labels that collapse into an unreadable web.

